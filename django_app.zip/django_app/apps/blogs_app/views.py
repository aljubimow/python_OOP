from django.shortcuts import render, HttpResponse, redirect
# the index function is called when root is visited
def index(request):
  index ="placeholder to later display all the list of blogs"
  return HttpResponse (index)

def new (request):
  new ="placeholder to display a new form to create a new blog"
  return HttpResponse(new)

def create (request):
  return redirect ('/')

def show (request, number):
  show ="placeholder to display a new form to create a new blog " + (number)
  return HttpResponse(show)

def edit (request, number):
  edit ="placeholder to edit blog " + (number)
  return HttpResponse(edit)

def destroy(request, number):
  return redirect ('/')